const mongoose = require('mongoose');

const bookSchema = new mongoose.Schema({
  title: {
    type: String,
    required: [true, 'Title is required'],
    trim: true,
  },
  isbn: {
    type: String,
    required: [true, 'ISBN is required'],
    unique: true,
    trim: true,
  },
  author: {
    type: String,
    trim: true,
  },
  genre: {
    type: String,
    trim: true,
  },
  price: {
    type: Number,
    min: [0, 'Price cannot be negative'],
    max: [9999, 'Price cannot exceed 9999'],
  },
  stock: {
    type: Number,
    default: 0,
    min: [0, 'Stock cannot be negative'],
  },
  publishedYear: {
    type: Number,
    min: 1000,
    max: new Date().getFullYear(),
  },
  createdAt: {
    type: Date,
    default: Date.now,
  },
});

module.exports = mongoose.model('Book', bookSchema);
