const express = require('express');
const router = express.Router();
const Book = require('../models/Book');

// ── GET /api/books — fetch all books ────────────────────────────────────────
router.get('/', async (req, res) => {
  try {
    const books = await Book.find().sort({ createdAt: -1 });
    res.json({ success: true, count: books.length, data: books });
  } catch (err) {
    res.status(500).json({ success: false, message: err.message });
  }
});

// ── POST /api/books — add a new book ────────────────────────────────────────
router.post('/', async (req, res) => {
  try {
    const book = new Book(req.body);
    const saved = await book.save();
    res.status(201).json({ success: true, data: saved });
  } catch (err) {
    // Handle duplicate ISBN (unique index violation)
    if (err.code === 11000) {
      return res.status(409).json({
        success: false,
        message: 'A book with that ISBN already exists.',
      });
    }
    res.status(400).json({ success: false, message: err.message });
  }
});

// ── GET /api/books/:id — get one book by ID ──────────────────────────────────
router.get('/:id', async (req, res) => {
  try {
    const book = await Book.findById(req.params.id);
    if (!book) {
      return res.status(404).json({ success: false, message: 'Book not found.' });
    }
    res.json({ success: true, data: book });
  } catch (err) {
    res.status(400).json({ success: false, message: err.message });
  }
});

// ── PUT /api/books/:id — update a book ──────────────────────────────────────
router.put('/:id', async (req, res) => {
  try {
    const book = await Book.findByIdAndUpdate(
      req.params.id,
      req.body,
      { new: true, runValidators: true }
    );
    if (!book) {
      return res.status(404).json({ success: false, message: 'Book not found.' });
    }
    res.json({ success: true, data: book });
  } catch (err) {
    res.status(400).json({ success: false, message: err.message });
  }
});

// ── DELETE /api/books/:id — delete a book ───────────────────────────────────
router.delete('/:id', async (req, res) => {
  try {
    const book = await Book.findByIdAndDelete(req.params.id);
    if (!book) {
      return res.status(404).json({ success: false, message: 'Book not found.' });
    }
    res.json({ success: true, message: `"${book.title}" deleted successfully.` });
  } catch (err) {
    res.status(400).json({ success: false, message: err.message });
  }
});

module.exports = router;
